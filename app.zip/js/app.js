document.addEventListener("DOMContentLoaded", function() {

	$(".toggle-mnu").click(function() {
	  $(this).toggleClass("on");
	  $(".header-mobile-menu").slideToggle();
	  return false;
	});

	$("body").append('<div class="top"><i class="fa fa-angle-up"></i></div>');

	$("body").on("click", ".top", function() {
		$("html, body").animate({scrollTop: 0}, "slow");
	});

	$(window).scroll(function() {
		if($(this).scrollTop() > $(this).height()) {
			$(".top").addClass("active");
		} else {
			$(".top").removeClass("active");
		}
	});

	 var owl = $('.katalog_gallery');
		owl.owlCarousel({
			items: 3,
			center: true,
			dots: false,
			loop: true,
			margin: 20,
			responsive : {
		  0 : {
		      items: 1,
		      center: false
		  },
		  992 : {
		      items: 3,
		  }
		}
		});
		// Go to the next item
		$('.katalog_gallery-next').click(function() {
		    owl.trigger('next.owl.carousel');
		});
		// Go to the previous item
		$('.katalog_gallery-prev').click(function() {
		    // With optional speed parameter
		    // Parameters has to be in square bracket '[]'
		    owl.trigger('prev.owl.carousel', [300]);
		});

		 var owl2 = $('.reviews_gallery');
			owl2.owlCarousel({
				items: 3,
				center: true,
				dots: false,
				loop: true,
				margin: 20,
				responsive : {
			  0 : {
			      items: 1,
			      center: false
			  },
			  992 : {
			      items: 3,
			  }
			}
			});
			// Go to the next item
			$('.reviews_gallery-next').click(function() {
			    owl2.trigger('next.owl.carousel');
			});
			// Go to the previous item
			$('.reviews_gallery-prev').click(function() {
			    // With optional speed parameter
			    // Parameters has to be in square bracket '[]'
			    owl2.trigger('prev.owl.carousel', [300]);
			});

			// var owl3 = $('.catalog-banner');
			// owl3.owlCarousel({
			// 	items: 1,
			// 	center: true,
			// 	dots: false,
			// 	loop: true,
			// 	autoplay: true,
			// 	autoplayTimeout: 4000,
			// 	autoplayHoverPause: true,
			// 	itemElement: 'catalog-banner-slide',
			// 	responsive : {
			//   0 : {
			//       items: 1,
			//   },
			//   992 : {
			//       items: 1,
			//   }
			// }
			// });
			// // Go to the next item
			// $('.reviews_gallery-next').click(function() {
			//     owl3.trigger('next.owl.carousel');
			// });
			// // Go to the previous item
			// $('.reviews_gallery-prev').click(function() {
			//     // With optional speed parameter
			//     // Parameters has to be in square bracket '[]'
			//     owl3.trigger('prev.owl.carousel', [300]);
			// });

		$('input, textarea').focus(function(){
	  $(this).parents('.form-group').addClass('focused');
	});

	$('input, textarea').blur(function(){
	  var inputValue = $(this).val();
	  if ( inputValue == "" ) {
	    $(this).removeClass('filled');
	    $(this).parents('.form-group').removeClass('focused');  
	  } else {
	    $(this).addClass('filled');
	  }
	});

    $( ".catalog-sidebar" ).accordion({
    	collapsible: true,
    	header: '> .catalog-sidebar-item > .catalog-sidebar-title',
    	active: 0,
    	heightStyle: "content"
    });

    $( ".catalog-sidebar-child" ).accordion({
    	collapsible: true,
    	header: '> .catalog-sidebar-child-item > .catalog-sidebar-child-title',
    	active: false,
    	heightStyle: "content"
    });

    $( ".catalog-sidebar-mobile" ).accordion({
    	collapsible: true,
    	active: false,
    	heightStyle: "content"
    });

});
